from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),

    # Home
    path('', include('home.urls')),

    # Other apps
    path('about/', include('AboutApp.urls')),
    path('contact/', include('ContactApp.urls')),
    path('media/', include('MediaApp.urls')),
    path('service/', include('ServiceApp.urls')),
    path('team/', include('TeamApp.urls')),
    path('testimonial/', include('TestimonialApp.urls')),
    path('countries/', include('countries.urls')),

    # ✅ STUDENTS API
    path('students/', include('students.urls')),
    path('rajan/', include('rajan.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
