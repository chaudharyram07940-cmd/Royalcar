from django.shortcuts import render

def about_page(request):
    return render(request, 'AboutApp/about.html')
