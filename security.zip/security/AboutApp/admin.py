from django.contrib import admin
from .models import AboutSection

admin.site.register(AboutSection)
