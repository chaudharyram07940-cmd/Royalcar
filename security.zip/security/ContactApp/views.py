from django.shortcuts import render
from django.core.mail import send_mail
from .forms import ContactForm
from .models import Contact

def contact_form(request):
    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']

            # Save in database
            Contact.objects.create(
                name=name,
                email=email,
                subject=subject,
                message=message
            )

            # Email send
            send_mail(
                subject,
                f"Message from: {name}\nEmail: {email}\n\nMessage:\n{message}",
                email,                     # sender email
                ['yourgmail@gmail.com'],   # receiver email
            )

            return render(request, "success.html")

    else:
        form = ContactForm()

    return render(request, "index.html", {"contact_form": form})
