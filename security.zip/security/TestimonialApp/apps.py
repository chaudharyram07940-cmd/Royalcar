from django.apps import AppConfig


class TestimonialappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'TestimonialApp'
