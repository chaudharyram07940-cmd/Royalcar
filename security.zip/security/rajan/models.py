from django.db import models
class Rajan(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    email = models.EmailField(unique=True)
    phonenumber=models.CharField(max_length=15)

    def __str__(self):
        return self.name2
