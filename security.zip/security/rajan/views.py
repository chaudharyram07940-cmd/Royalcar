from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Rajan
from .serializers import RajanSerializer

@api_view(['GET'])
def home_page(request):
    return Response({"message": "Welcome to the Rajan API "})

@api_view(['GET'])
def get_all_rajan(request):
    rajan=Rajan.objects.all()
    serializer=RajanSerializer(rajan,many=True)
    return Response(serializer.data)
@api_view(['POST'])
def create_rajan(request):
    serializer=RajanSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(
            {"message":"Rajan add successfully", "data":serializer.data},
        )
    return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
@api_view(['GET'])
def get_rajan_by_id(request, id):
    rajan=get_object_or_404(Rajan, id=id)
    serializer=RajanSerializer(rajan)
    return Response(serializer.data)