from django.urls import path
from . import views
urlpatterns = [
    path('', views.get_all_rajan, name='get-rajan'),
    path('add/', views.create_rajan, name='add_rajan'),
    path('<int:id>/', views.get_rajan_by_id, name='get-rajan-by-id'),
]
