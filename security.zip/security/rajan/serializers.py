from rest_framework import serializers
from.models import Rajan
class RajanSerializer(serializers.ModelSerializer):
    class Meta:
        model = Rajan
        fields = ['_all_']
