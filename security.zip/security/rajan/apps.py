from django.apps import AppConfig


class RajanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rajan'
