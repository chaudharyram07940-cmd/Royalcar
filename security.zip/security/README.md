# Minimal Django wiring for templates

This repository contains a set of HTML templates and static assets. I added a minimal Django project package (`security`) and a tiny `core` app so you can run the development server and serve templates using Django's template engine.

What I added
- `security/settings.py`, `security/urls.py`, `security/wsgi.py`
- `core/` app with `urls.py` and `apps.py`
- `requirements.txt`

How to run (Windows PowerShell)

1. Create a virtual environment and install dependencies:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2. Run migrations and start the dev server:

```powershell
python manage.py migrate
python manage.py runserver
```

Notes
- The templates reference static files under `{% static '...' %}`. `STATICFILES_DIRS` is set to the existing `script/` folder in the repo root.
- I inferred URL names (`index`, `about`, `service`, etc.) and created routes at paths like `/about/`. If your URL names or desired paths differ, tell me the preferred names and I'll update them.
