import requests
from django.shortcuts import render
from django.conf import settings
from django.core.cache import cache
from django.http import JsonResponse

API_URL = "https://api.first.org/data/v1/countries"

def countries_list(request):
    # try cache first (cache key 'countries_data', timeout 1 hour)
    data = cache.get("countries_data")
    if data is None:
        try:
            resp = requests.get(API_URL, timeout=8)
            resp.raise_for_status()
            json_data = resp.json()
            # json_data['data'] is a dict keyed by country code per API
            # Convert to list of dicts for easier templating:
            raw = json_data.get("data", {})
            data = []
            for code, info in raw.items():
                # example fields: country, region, capital (depends on API)
                data.append({
                    "code": code,
                    "country": info.get("country"),
                    "region": info.get("region"),
                    "region_code": info.get("region_code"),
                    "currency": info.get("currency"),
                })
            # store in cache
            cache.set("countries_data", data, 60 * 60)  # 1 hour
        except requests.RequestException as e:
            # handle network/API error
            data = []
            # optionally pass error message
            return render(request, "countries/list.html", {"countries": data, "error": str(e)})
    return render(request, "countries/list.html", {"countries": data})


def countries_api(request):
    # return cached data if present
    data = cache.get("countries_data")
    if data is None:
        # fetch like earlier
        try:
            resp = requests.get(API_URL, timeout=8)
            resp.raise_for_status()
            raw = resp.json().get("data", {})
            data = []
            for code, info in raw.items():
                data.append({
                    "code": code,
                    "country": info.get("country"),
                    "region": info.get("region"),
                })
            cache.set("countries_data", data, 60*60)
        except requests.RequestException as e:
            return JsonResponse({"error": str(e)}, status=500)
    return JsonResponse({"countries": data})
