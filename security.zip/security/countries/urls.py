from django.urls import path
from . import views

urlpatterns = [
    path("", views.countries_list, name="countries_list"),
    path("api/", views.countries_api, name="countries_api"),

]
