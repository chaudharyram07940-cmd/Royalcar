from django.db import models

class Car(models.Model):
    name = models.CharField(max_length=200)
    year = models.CharField(max_length=10)
    gear_type = models.CharField(max_length=50)
    km_driven = models.CharField(max_length=20)
    price_per_day = models.CharField(max_length=20)
    image = models.ImageField(upload_to='cars/')

    def __str__(self):
        return self.name
