from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='index'),
    path('about/', views.about, name='about'),
    
    # duplicate home URL hata diya
    path('service/', views.service, name='service'),

    path('car/', views.car, name='car'),
    path('booking/', views.booking, name='booking'),
    path('testimonial/', views.testimonial, name='testimonial'),
    path('contact/', views.contact, name='contact'),

    # countries page (API fetch from views.countries)
    path('countries/', views.countries, name='countries'),
]
