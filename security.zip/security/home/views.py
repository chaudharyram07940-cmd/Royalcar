import requests
from django.shortcuts import render
from .models import Section
from MediaApp.models import Car
from ServiceApp.models import Service
from TeamApp.models import Team
from TestimonialApp.models import Testimonial
from ContactApp.forms import ContactForm


def home(request):
    sections = Section.objects.all()
    cars = Car.objects.all()
    services = Service.objects.all()
    teams = Team.objects.all()
    testimonials = Testimonial.objects.all()
    form = ContactForm()

    return render(request, "index.html", {
        "sections": sections,
        "cars": cars,
        'services': services,
        'teams': teams,
        'testimonials': testimonials,
        'contact_form': form,
    })


def about(request):
    return render(request, "about.html")


def service(request):
    return render(request, "service.html")


def car(request):
    return render(request, "car.html")


def booking(request):
    return render(request, "booking.html")


def testimonial(request):
    return render(request, "testimonial.html")


def contact(request):
    return render(request, "contact.html")


# ✅ Countries API Fetch Function (FINAL WORKING CODE)
def countries(request):
    url = "https://api.first.org/data/v1/countries"
    response = requests.get(url)

    countries = {}

    if response.status_code == 200:
        data = response.json()
        countries = data.get("data", {})

    return render(request, "countries.html", {
        "countries": countries
    })
