from django.shortcuts import render
from .models import Team

def team_page(request):
    team = Team.objects.all()
    return render(request, "index.html", {"team": team})
